module.exports = {
    key: process.env.NEWS_API_KEY
};